#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on a sunny day

@author: David Lee
@id: R00108718
@Cohort: CS3
"""
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import KFold, train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA


def Task1():
    print("Task1:\n")
    df = pd.read_csv("humanDetails.csv", encoding="ISO-8859-1", skipinitialspace=True)
    newdf = df[['native-country','workclass', 'age', 'Income']].copy()

    newdf = newdf.drop(newdf[newdf["workclass"] == '?'].index)
    newdf = newdf.drop(newdf[newdf["native-country"] == '?'].index)

    for i, age in enumerate(newdf["age"]):
        clean_age = int(age.replace('s', ''))
        newdf.loc[i, "age"] = clean_age
    newdf["age"] = newdf["age"].astype(int)
    newdf = newdf.dropna(subset=["native-country", "workclass", "age", "Income"])
    map_income = {'<=50K': 0, '>50K': 1}
    newdf['Income'] = newdf['Income'].map(map_income)

    workclass = LabelEncoder()
    newdf["workclass"] = workclass.fit_transform(newdf["workclass"])

    X = np.array(newdf[["age", "workclass"]])
    y = np.array(newdf["Income"])

    n_folds = 5
    testing_size = 0.2

    newdf = newdf.groupby("native-country")

    overfitting_countries = []
    overfitting_gaps = []

    for name, group in newdf:
        country_df = pd.DataFrame(group)
        if country_df.shape[0] < 2:
            print(f"***{name} has to little of a sample size ({country_df.shape[0]}) for cross validation")
            continue

        X = np.array(country_df[["age", "workclass"]])
        y = np.array(country_df["Income"])
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=testing_size, random_state=42)

        scores = []
        best_score = 0
        best_depth = None
        kf = KFold(n_splits=n_folds, shuffle=True, random_state=42)
        for train_index, test_index in kf.split(X_train, y_train):
            X_train, X_test = X[train_index], X[test_index]
            y_train, y_test = y[train_index], y[test_index]
            for max_depth in range(2, 20):
                model = DecisionTreeClassifier(max_depth=max_depth)
                model.fit(X_train, y_train)

                gap = (model.score(X_train, y_train) - model.score(X_test, y_test)) / model.score(X_train, y_train)
                if gap > 0.2:
                    overfitting_countries.append(name)
                    overfitting_gaps.append(gap)

                y_pred = model.predict(X_test)
                score = accuracy_score(y_test, y_pred)
                scores.append(score)
                if score > best_score:
                    best_score = score
                    best_depth = max_depth
        print(f"Best accuracy for {name} with max_depth = {best_depth} = {best_score}")

    plt.figure(figsize=(15,7))
    plt.bar(overfitting_countries, overfitting_gaps)
    plt.xlabel("Country")
    plt.ylabel("Gap between training and test accuracy")
    plt.title("Overfitting Countries")
    plt.xticks(rotation=90, fontsize = 'xx-small')
    plt.show()


def Task2():
    print("Task2:\n")
    df = pd.read_csv("humanDetails.csv", encoding="ISO-8859-1", skipinitialspace=True)
    newdf = df[['occupation ', "relationship", 'age', "hours-per-week", 'Income']].copy()

    most_common = newdf['occupation '].value_counts().idxmax()
    newdf['occupation '].fillna(most_common, inplace=True)

    for i, age in enumerate(newdf['age']):
        clean_age = int(age.replace('s', ''))
        newdf.loc[i, 'age'] = clean_age

    newdf = newdf.drop(newdf[newdf["relationship"] == "Other-relative"].index)

    counts = newdf["hours-per-week"].value_counts()
    newdf = newdf[newdf["hours-per-week"].isin(counts[counts > 1].index)]

    map_income = {'<=50K': 0, '>50K': 1}
    newdf['Income'] = newdf['Income'].map(map_income)

    lbl_encoder = LabelEncoder()
    newdf["occupation "] = lbl_encoder.fit_transform(newdf["occupation "])
    newdf["relationship"] = lbl_encoder.fit_transform(newdf["relationship"])

    X = np.array(newdf[['hours-per-week', 'occupation ', 'age', 'relationship']])
    y = np.array(newdf['Income'])

    n_folds = 5
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    kf = KFold(n_splits=n_folds, shuffle=True, random_state=42)
    for train_index, test_index in kf.split(X_train, y_train):
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]

        best_train_accuracy_dtc = 0
        best_Test_accuracy_dtc = 0
        best_train_accuracy_knn = 0
        best_Test_accuracy_knn = 0
        best_dept_dtc = None
        best_dept_knn = None
        for max_depth in range(2, 10):
            clf = DecisionTreeClassifier(max_depth=max_depth)
            clf.fit(X_train, y_train)

            train_accuracy_dtc = clf.score(X_train, y_train)
            test_accuracy_dtc = clf.score(X_test, y_test)
            if train_accuracy_dtc > best_train_accuracy_dtc:
                if test_accuracy_dtc > best_Test_accuracy_dtc:
                    best_train_accuracy_dtc = train_accuracy_dtc
                    best_Test_accuracy_dtc = test_accuracy_dtc
                    best_dept_dtc = max_depth

            clf = KNeighborsClassifier(n_neighbors=max_depth)
            clf.fit(X_train, y_train)
            train_accuracy_knn = clf.score(X_train, y_train)
            test_accuracy_knn = clf.score(X_test, y_test)
            if train_accuracy_knn > best_train_accuracy_knn:
                if test_accuracy_knn > best_Test_accuracy_knn:
                    best_train_accuracy_knn = train_accuracy_knn
                    best_Test_accuracy_knn = test_accuracy_knn
                    best_dept_knn = max_depth

    print("Decision tree classifier:")
    print(f"Best Train accuracy: {best_train_accuracy_dtc} at depth: {best_dept_dtc}")
    print(f"Best Test accuracy: {best_train_accuracy_dtc} at depth: {best_dept_dtc}")
    print("KNN classifier:")
    print(f"Best Train accuracy: {best_train_accuracy_knn} at depth: {best_dept_knn}")
    print(f"Best Test accuracy: {best_Test_accuracy_knn} with number of neighbours: {best_dept_knn}")

    accuracies = [
        ("Decision Tree", best_train_accuracy_dtc, best_train_accuracy_dtc),
        ("KNN", best_train_accuracy_knn, best_Test_accuracy_knn)
    ]
    labels, train_accuracies, test_accuracies = zip(*accuracies)

    bar_width = 0.25
    bars1 = train_accuracies
    bars2 = test_accuracies

    r1 = np.arange(len(bars1))
    r2 = [x + bar_width for x in r1]

    plt.bar(r1, bars1, width=bar_width, edgecolor='white', label='Train Accuracy')
    plt.bar(r2, bars2, width=bar_width, edgecolor='white', label='Test Accuracy')
    plt.xlabel('classifier', fontweight='bold')
    plt.xticks([r + bar_width / 2 for r in range(len(bars1))], labels)
    plt.legend(loc = 'upper center')
    plt.title("Task 2: Decission Tree Classifier and K-Nearest Neighbour", loc='center')
    plt.show()

def Task3():
    df = pd.read_csv("humanDetails.csv", encoding="ISO-8859-1", skipinitialspace=True)
    newdf = df[['fnlwgt', "education-num", 'age', "hours-per-week", 'Income']].copy()

    for i, age in enumerate(newdf['age']):
        clean_age = int(age.replace('s', ''))
        newdf.loc[i, 'age'] = clean_age

    map_income = {'<=50K': 0, '>50K': 1}
    newdf['Income'] = newdf['Income'].map(map_income)

    scaler = StandardScaler()
    df_scaled = scaler.fit_transform(newdf)

    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(df_scaled)

    kmeans = KMeans(n_clusters=2)
    kmeans.fit(X_pca)

    x = X_pca[:,0]
    y = X_pca[:,1]

    income = newdf['Income']
    plt.scatter(x, y, c=income, cmap='viridis')
    plt.xlabel('Principal component analysis X')
    plt.ylabel('Principal component analysis Y')
    plt.title("Task 3: Principal component analysis", loc='center')
    plt.show()

    labels = kmeans.predict(X_pca)
    plt.scatter(x, y, c=labels, cmap='viridis')
    plt.xlabel('K-Means clustering X')
    plt.ylabel('K-Means clustering Y')
    plt.title("Task 3: K-Means clustering", loc='center')
    plt.show()

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))
    ax1.scatter(x, y, c=income, cmap='viridis')
    ax1.set_xlabel('Principal component analysis X')
    ax1.set_ylabel('Principal component analysis Y')
    ax1.set_title("Task 3: Principal component analysis", loc='center')
    ax2.scatter(x, y, c=labels, cmap='viridis')
    ax2.set_xlabel('K-Means clustering X')
    ax2.set_ylabel('K-Means clustering Y')
    ax2.set_title("Task 3: K-Means clustering", loc='center')
    plt.show()

Task1()
Task2()
Task3()