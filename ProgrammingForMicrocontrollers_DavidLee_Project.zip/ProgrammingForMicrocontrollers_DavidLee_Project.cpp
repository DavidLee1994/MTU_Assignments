/**
David Lee
R00108718
Programming for Microcontrollers
Assignment2
**/

#include "mbed.h"
#include "C12832.h"
#include "LM75B.h"
#include "MMA7660.h"
#include <math.h>
#include <stdio.h>


MMA7660 MMA(p28, p27);
C12832 lcd(p5,p7,p6,p8,p11);
DigitalOut connectionLed(LED1);
LM75B sensor(p28,p27);
Serial pc(USBTX,USBRX);
PwmOut r (p23);
PwmOut g (p24);
PwmOut b (p25);
PwmOut spkr (p26);
DigitalIn potent(p14);
AnalogIn pot1(p19);
AnalogIn pot2(p20);

void rgbinterrupt(char* colour){
    r.period(0.1);
    float i = 0;
    float p = 3 * i;
    if (colour == "r"){
        r = 1.0 - ((p < 1.0) ? 1.0 - p : (p > 2.0) ? p - 2.0 : 0.0);  //Red
        g = 1.0 - ((p < 1.0) ? p : (p > 2.0) ? 0.0 : 2.0 - p);
        b = 1.0 - ((p < 1.0) ? 0.0 : (p > 2.0) ? 3.0 - p : p - 1.0);
        thread_sleep_for(25);
        r = 0;
        g = 0;
        b = 0;
    }
    else if (colour == "b"){
        r = 1.0 - ((p < 1.0) ? p : (p > 2.0) ? 0.0 : 2.0 - p);        //Blue
        g = 1.0 - ((p < 1.0) ? 0.0 : (p > 2.0) ? 3.0 - p : p - 1.0);
        b = 1.0 - ((p < 1.0) ? 1.0 - p : (p > 2.0) ? p - 2.0 : 0.0);
        thread_sleep_for(25);
        r = 0;
        g = 0;
        b = 0;
    }
}

void spkrinterrupt(){
    spkr.period(1.0/500.0);
    spkr =0.5;
    thread_sleep_for(10);
    spkr=0.0;
    thread_sleep_for(10);
}

int main()
{
    float x1=0,y1=0,z1=0;
    float temp_thresh = 0, adcthresh_blue = .3, adcthresh_red = .6;
    float i = 0;
    float p = 3 * i;
    float ADCdata1, ADCdata2;
    r.period(0.1);
    lcd.cls();
    if (MMA.testConnection() && sensor.read())
        connectionLed = 1;
        pc.printf("Accelerometer and Thermometer Connected\n\r");
    while(1) {
        x1 = MMA.x()*3.3;
        y1 = MMA.y()*3.3;
        z1 = MMA.z()*3.3;
        float data[3] = {x1, y1, z1};
        pc.printf("Accelerometer x =%f\n\rAccelerometer y =%f\n\rAccelerometer z =%f\n\r\n", x1, y1 , z1);
        ADCdata1 = pot1;
        ADCdata2 = pot2;
        pc.printf("ADCData1 = %f\n\r", ADCdata1);
        pc.printf("ADCData2 = %f\n\r", ADCdata2);
        if (ADCdata2 <=.3){
            temp_thresh = 24;
        }
        else if ((ADCdata2 >.3) && (ADCdata2 <=.6)) {
            temp_thresh = 27;
        }
        else{
            temp_thresh = 30;
        }
        lcd.locate(0,3);
        lcd.printf("Thresholds\n\rHz-Blue =%.2f\t Hz Red =%.2f\nTemp =%.2f\n", adcthresh_blue, adcthresh_red, temp_thresh);
        float cel = (float)sensor.read();
        pc.printf("Celcius = %f\n\n", cel);
        if ((cel <temp_thresh) && (ADCdata1 < adcthresh_blue)){
            r = 1.0 - ((p < 1.0) ? 0.0 : (p > 2.0) ? 3.0 - p : p - 1.0);  //Green
            g = 1.0 - ((p < 1.0) ? 1.0 - p : (p > 2.0) ? p - 2.0 : 0.0);
            b = 1.0 - ((p < 1.0) ? p : (p > 2.0) ? 0.0 : 2.0 - p);
        }

        else if ((cel <temp_thresh) && (ADCdata1 >adcthresh_blue)){
            rgbinterrupt("b");
            pc.printf("Warning! Hz above threshold\n\n");
        }

        else if ((cel >=temp_thresh) && (ADCdata1 >adcthresh_red)){
            rgbinterrupt("r");
            spkrinterrupt();
            pc.printf("Warning!! Hz and temperature above thresholds\n\n");
        }
    }
    wait(.5);
}
    
